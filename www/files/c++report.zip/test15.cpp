#include <iostream>
 using std::cout;
 using std::ios;


 #include <iomanip>
 using std::setw;
 using std::setprecision;
 using std::setiosflags;
 using std::resetiosflags;

 #include <cstdlib>
 #include <ctime>

 void shuffle( int [][ 13 ] );
 void deal( const int [][ 13 ], const char *[], const char *[] );

 int main()
 {
 int card = 1, deck[ 4 ][ 13 ] = { 0 };
 const char *suit[ 4 ] = { "Hearts", "Diamonds", "Clubs", "Spades" };
 const char *face[ 13 ] = { "Ace", "Deuce", "Three", "Four", "Five", "Six",
 "Seven", "Eight", "Nine", "Ten", "Jack", "Queen",
 "King" };

 srand( time( 0 ) );

 // initialize deck
 for ( int row = 0; row <= 3; ++row )
 for ( int column = 0; column <= 12; ++column )
 deck[ row ][ column ] = card++;

 shuffle( deck );
 deal( deck, face, suit );

 return 0;
 }

 void shuffle( int workDeck[][ 13 ] )
 {
 int temp, randRow, randColumn;

 for ( int row = 0; row <= 3; ++row )
 for ( int column = 0; column <= 12; ++column ) {
 randRow = rand() % 4;
 randColumn = rand() % 13;
 temp = workDeck[ row ][ column ];
 workDeck[ row][ column ] = workDeck[ randRow ][ randColumn ];
 workDeck[ randRow ][ randColumn ] = temp;
 }

 }

 void deal( const int workDeck2[][ 13 ], const char *workFace[],
 const char *workSuit[] )
 {
 for ( int card = 1; card <= 52; ++card )
 for ( int row = 0; row <= 3; ++row )
 for ( int column = 0; column <= 12; ++column )
 if ( workDeck2[ row ][ column ] == card ) {
 cout << setw( 8 ) << workFace[ column ] << " of "
 << setiosflags( ios::left ) << setw( 8 )
 << workSuit[ row ]
 << ( card % 2 == 0 ? '\n' : '\t' )
 << resetiosflags( ios::left );
 break;
 }
 }